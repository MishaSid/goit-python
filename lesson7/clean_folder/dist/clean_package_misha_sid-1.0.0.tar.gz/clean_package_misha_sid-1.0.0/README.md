My project

Usage: this package is used to rename all files and folders (including subfolders and files in them) into Latin.
       It deletes all empty folders and sort the files with particular extensions:

       'JPEG', 'PNG', 'JPG', 'SVG' to Images folder
       'AVI', 'MP4', 'MOV', 'MKV' to Videos folder
       'DOC', 'DOCX', 'TXT', 'PDF', 'XLSX', 'PPTX' to Documents folder
       'MP3', 'OGG', 'WAV', 'AMR' to Audio folder
       Unpack 'ZIP', 'GZ', 'TAR'.

       The detailed description is described in clean.py file.

Install: python3 -m pip install clean_package_misha_sid

Notes: Verified to run on Windows.